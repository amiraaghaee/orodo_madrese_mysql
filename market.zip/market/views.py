"""
    You can define utility functions here if needed
    For example, a function to create a JsonResponse
    with a specified status code or a message, etc.

    DO NOT FORGET to complete url patterns in market/urls.py
"""
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from .models import Product
from .serializers import ProductSerializer


@csrf_exempt
def product_list(request):
    if request.method == 'GET':
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return JsonResponse(serializer.data, safe=False)
    else:
        return JsonResponse({"message": "Duplicate code."}, status=400)


@csrf_exempt
def product_insert(request):
    if request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = ProductSerializer(data=data)
        cheak_product = Product.objects.filter(code=data["code"])
        if cheak_product.exists():
            return JsonResponse({"message": "Duplicate code ."}, status=400)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)

        return JsonResponse({"message": "Duplicate code "}, status=400)


@csrf_exempt
def product_search(request, search):
    try:
        product = Product.objects.get(name__regex=search)
    except Product.DoesNotExist:
        return JsonResponse({"message": "Product Not Found."}, status=404)

    if request.method == 'GET':
        serializer = ProductSerializer(product)
        return JsonResponse(serializer.data, status=200)
    return JsonResponse({"message": "Duplicate code."}, status=400)


@csrf_exempt
def product_detail(request, pk):
    try:
        product = Product.objects.get(pk=pk)
    except Product.DoesNotExist:
        return JsonResponse({"message": "Product Not Found."}, status=404)

    if request.method == 'GET':
        serializer = ProductSerializer(product)
        return JsonResponse(serializer.data, status=200)
    return JsonResponse({"message": "Duplicate code."}, status=400)


@csrf_exempt
def product_update(request, pk):
    try:
        product = Product.objects.get(pk=pk)
    except Product.DoesNotExist:
        return JsonResponse({"message": "Product Not Found."}, status=404)

    if request.method == 'GET':
        serializer = ProductSerializer(product)
        return JsonResponse(serializer.data, safe=False)
    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = ProductSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
        else:
            return JsonResponse({"message": "Not enough inventory."}, status=400)
        return JsonResponse(serializer.data)


